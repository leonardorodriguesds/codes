import System.IO
import Data.Array.IO

main = do