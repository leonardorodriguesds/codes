#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    scanf("%d", &n);
    vector<int> wagons(n, 0);
    iota(wagons.begin(), wagons.end(), 0);
    stack<int> aux;
	return 0;
}