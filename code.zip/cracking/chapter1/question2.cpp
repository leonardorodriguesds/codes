#include <bits/stdc++.h>
using namespace std;

int main(){
    string str1, str2;
    cin >> st1 >> str2;
    return 0;
}