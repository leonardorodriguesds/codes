#include <bits/stdc++.h>
using namespace std;

int main(){
    string a, b;
    cin >> a >> b;
    if(a == b)
        printf("%s\n", a.c_str());
    else
        printf("1\n");
    return 0;
}