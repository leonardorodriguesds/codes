#include <bits/stdc++.h>
#include <inttypes.h>
using namespace std;

int main(){
  int n, m, i, j;
  scanf("%d %d", &n, &m);
  string linem, colunm(m, '0'), lines(n, '0');
  for(i = 0; i < n; i++){
    cin >> line;
    for(j = 0; j < m; j++){
      if(line[j] == '1'){
	
      }
    }
  }
  printf("%dx%d\n", (c_start - c_end >= 0? c_start - c_end : -c_start + c_end), (l_start - l_end >= 0? l_start - l_end : -l_start + l_end));
  return 0;
}
