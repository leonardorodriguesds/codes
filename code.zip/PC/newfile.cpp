#include <bits/stdc++.h>
#define check_bit(var, pos)	    (((var) & (1 << (pos)))
#define toggle_bit(var, pos)	((var) ^= (1 << (pos)))
#define set_bit(var, pos)	    ((var) |= (1 << (pos)))
#define clear_bit(var, pos)	    ((var) &= (0 << (pos)))
using namespace std;

int main(){
    return 0;
}
