#include <bits/stdc++.h>
using namespace std;

int main(){
    int n, k, a, m, i, j, shot;
    scanf("%d %d %d %d", &n, &k, &a, &m);

    for(i = 0; i < m; i++){
       
    }
    return 0;
}