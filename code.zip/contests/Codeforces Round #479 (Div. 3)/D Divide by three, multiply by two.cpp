#include <bits/stdc++.h>
using namespace std;

int main(){
    int n, i;
    scanf("%d", &n);
    vector<long long> numbers(n, 0);
    vector<long long> ans(n, 0);
    long long num;
    for(i = 0; i < n; i++)
        scanf("%lld", &numbers[i]);
    for(i = 0; i < n; i++){
        
    }
    return 0;
}