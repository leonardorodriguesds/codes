Aritmética Modular
==================

Conceitos Básico
----------------

- Congruência
- Propriedades

Inverso Multiplicativo
----------------------

- Euclides estendido

Teorema de Fermat
-----------------

- Cálculo do inverso por exponenciação rápida

Teorema de Euler
----------------

Teorema de Wilson
-----------------

Teorema Chinês dos Restos
-------------------------
