# TEP

Material da disciplina Tópicos Especiais em Programação da Faculdade UnB Gama.

1. [Introdução](Introducao/README.md)
1. [Estruturas de Dados](Estruturas_de_Dados/README.md)
1. [Strings](Strings/README.md)
1. [Geometria Computacional](Geometria_Computacional/README.md)
1. [Matemática](Matematica/README.md)
