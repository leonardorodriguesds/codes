#!/bin/bash
rm -f *.toc *.aux *.dvi *.ps *.snm *.log *.vrb *.out *.nav *.pdf a.out
rm -rf _minted-main
