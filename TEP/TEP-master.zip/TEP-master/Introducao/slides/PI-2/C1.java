import java.util.Scanner;

public class C1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int X = scanner.nextInt();
        int Y = scanner.nextInt();

        System.out.println(X + Y);
    }

}
