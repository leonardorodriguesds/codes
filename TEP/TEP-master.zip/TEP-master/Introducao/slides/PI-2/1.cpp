#include <iostream>

using namespace std;

int main()
{
    ios::sync_with_stdio(false);

    int X, Y;
    cin >> X >> Y;

    cout << X + Y << endl;

    return 0;
}
