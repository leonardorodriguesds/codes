import java.util.Scanner;

public class C4 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNext()) {
            int X = scanner.nextInt();
            int Y = scanner.nextInt();

            System.out.println(X + Y);
        }
    }

}
