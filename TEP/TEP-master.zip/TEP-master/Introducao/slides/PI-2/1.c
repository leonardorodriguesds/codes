#include <stdio.h>

int main()
{
    int X, Y;
    scanf("%d %d", &X, &Y);

    printf("%d\n", X + Y);

    return 0;
}
