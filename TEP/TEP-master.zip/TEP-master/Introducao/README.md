Introdução
==========

1. [Introdução](introducao.md)
1. [C++](cpp.md)
1. [C++ STL](STL.md)

Slides
======

1. Introdução
    1. [Introdução à Programação Competitiva](slides/PI-1/PI-1.pdf)
    1. [Juízes Eletrônicos](slides/PI-2/PI-2.pdf)
