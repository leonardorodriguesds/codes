Estruturas de Dados: Listas
===========================

1. [Estruturas Lineares](Estruturas_Lineares.md) ([PDF](Estruturas_Lineares.pdf))
1. [Estruturas Não-Lineares](Estruturas_Nao_Lineares.md) ([PDF](Estruturas_Nao_Lineares.pdf))
1. Grafos e _Union-Find_ ([PDF](Grafos_e_Union_Find.pdf))
1. _Segment Tree_ e _Fenwick Tree_ ([PDF](Segment_Tree_BIT_Tree.pdf))
