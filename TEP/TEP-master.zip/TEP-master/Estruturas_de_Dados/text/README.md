Estruturas de Dados
===================

1. [Estruturas de Dados Lineares](Estruturas_Lineares.md)
1. [Estruturas de Dados Não-Lineares](Estruturas_Nao_Lineares.md)
1. [Grafos e Union-Find](Grafos_Union_Find.md)
1. [Segment Tree e BIT Tree](Segment_Tree_BIT_Tree.md)
1. [Busca Completa](Busca_Completa.md)
1. [Dividir e Conquistar](Dividir_e_Conquistar.md)
1. [Algoritmos Gulosos](Gulosos.md)
1. [Programação Dinâmica](PD.md)
