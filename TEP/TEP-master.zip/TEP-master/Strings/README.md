Strings
=======

1. [Strings](text/Strings.md)
1. [Representação de Strings](text/Representacao_de_Strings.md)
1. [Algoritmos Elementares](text/Algoritmos_Elementares.md)
1. [Algoritmos de Busca](text/Algoritmos_de_Busca.md)
1. [Programação Dinâmica](text/Programacao_Dinamica.md)
1. [Árvores de Sufixos](text/Arvores_de_Sufixos.md)
